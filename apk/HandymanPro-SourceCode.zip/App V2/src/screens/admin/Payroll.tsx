
import React from 'react';
import { View } from 'react-native';
import { Text } from 'react-native-paper';

export default function Payroll(){
  return <View style={{flex:1, padding:16}}><Text>Payroll & rates (coming soon)</Text></View>
}
