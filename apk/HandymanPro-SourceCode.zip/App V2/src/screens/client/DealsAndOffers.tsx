
import React from 'react';
import { View } from 'react-native';
import { Text } from 'react-native-paper';

export default function DealsAndOffers(){
  return <View style={{flex:1, padding:16}}><Text>Deals and offers (coming soon)</Text></View>
}
