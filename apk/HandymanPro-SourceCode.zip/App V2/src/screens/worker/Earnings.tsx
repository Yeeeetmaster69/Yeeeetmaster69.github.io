
import React from 'react';
import { View } from 'react-native';
import { Text } from 'react-native-paper';

export default function Earnings(){
  return <View style={{flex:1, padding:16}}><Text>Earnings daily/weekly/monthly/total (coming soon)</Text></View>
}
