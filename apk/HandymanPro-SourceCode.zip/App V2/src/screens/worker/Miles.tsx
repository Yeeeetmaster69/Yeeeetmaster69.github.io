
import React from 'react';
import { View } from 'react-native';
import { Text } from 'react-native-paper';

export default function Miles(){
  return <View style={{flex:1, padding:16}}><Text>Travel log & export (coming soon)</Text></View>
}
